export function BrandLogo({ className = "h-auto w-48 max-w-full" }: { className?: string }) {
  return (
    <img
      src="/logo.png"
      alt="Spiral Systems Incorporated, Nesbit, Mississippi and Nashville, Tennessee"
      className={className}
    />
  );
}
